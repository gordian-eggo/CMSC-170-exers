#!/bin/bash

cd src && java -jar RuzEx1.jar