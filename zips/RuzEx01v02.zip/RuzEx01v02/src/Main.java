public class Main {
	public static void main(String[] args) {
		Board lights_out = new Board();
	}
}