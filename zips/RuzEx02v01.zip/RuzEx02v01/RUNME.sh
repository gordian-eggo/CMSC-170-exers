#!/bin/bash

cd src && java -jar RuzEx02v01.jar