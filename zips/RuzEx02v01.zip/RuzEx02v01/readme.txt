RUZ, Julianne Marie
2014-04280
CMSC 170 U-1L

Exercise 2b: DFS Solver for the Lights Out game

Software requirements: Ubuntu/Linux, Java