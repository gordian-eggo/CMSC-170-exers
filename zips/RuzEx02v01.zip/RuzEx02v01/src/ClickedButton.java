public class ClickedButton {

	protected int x_coor;
	protected int y_coor;

	public int get_x_coor() { return this.x_coor; }
	public int get_y_coor() { return this.y_coor; }

	public ClickedButton(int x, int y) {
		this.x_coor = x;
		this.y_coor = y;
	}

}